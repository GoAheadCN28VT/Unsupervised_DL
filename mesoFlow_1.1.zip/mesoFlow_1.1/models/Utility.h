#include <iostream>
#include <fstream>

//#include <exception>
//#include <stdexcept>


#include <sstream>
#include <cstring>

using namespace std;

class Utility
{


    public:



    void writeVtk_sparse_3D(float* vt, int _Nx, int _Ny, int _Nz, unsigned char *domainGMH, int *dense2SparseIndexGM, string nameVariable, string dirName, string fileName, int tStep);

//    template<typename T>
    void writeVtk_ExcludeHalo_3D(unsigned char *Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);
    void writeVtk_ExcludeHalo_3D(float*Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);


};
