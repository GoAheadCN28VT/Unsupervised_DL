#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <iostream>
#include <exception>
#include <stdexcept>
#include <fstream>
#include <mpi.h>
//#include <lbm.h>
#include <sstream>
#include <cstring>
#include <map>

#include <Utility.h>
#include <IOhub.h>
#include <communicator.h>
#include <diffusionCoefficientAnalyzer.h>



#define  blockDim_x       512

#define TAG_domain     1
#define TAG_f     2
#define TAG_ux     3
#define TAG_uy     4
#define TAG_uz     5
#define TAG_rho     6

#define TAG_grho     16
#define TAG_g     12

#define TAG_Index  100
#define TAG_analysis     101


#define TAG_t1    111
#define TAG_t2    112
#define TAG_t3    113
#define TAG_t4    114

typedef  float  Float;  //single phase

typedef  unsigned char  INT8;


using namespace std;
//                     0  1  2   3  4  5  6  7  8  9   10  11  12 13 14  15 16 17 18
const Float ex[19] = { 0, 1, -1, 0, 0, 0, 0, 1, 1, -1, -1, 1, -1, 1, -1, 0, 0, 0, 0 };
const Float ey[19] = { 0, 0, 0, 1, -1, 0, 0, 1, -1, 1, -1, 0,  0, 0,  0, 1, 1, -1, -1 };
const Float ez[19] = { 0, 0, 0, 0, 0, 1, -1, 0, 0,  0,  0, 1,  1,-1, -1, 1,-1, 1, -1 };

__constant__  Float exG[19] = { 0, 1, -1, 0, 0, 0, 0, 1, 1, -1, -1, 1, -1, 1, -1, 0, 0, 0, 0 };
__constant__  Float eyG[19] = { 0, 0, 0, 1, -1, 0, 0, 1, -1, 1, -1, 0,  0, 0,  0, 1, 1, -1, -1 };
__constant__  Float ezG[19] = { 0, 0, 0, 0, 0, 1, -1, 0, 0,  0,  0, 1,  1,-1, -1, 1,-1, 1, -1 };

const Float one = 1.0;
const Float three = 3.0;
const Float inv3 = 1.0/3;
const Float inv18 = 1.0/18;
const Float inv36 = 1.0/36;
const Float fourpt5 = 4.5;
const Float onept5 = 1.5;
const Float c_squinv = 3.0;



//void evolve_f_external();

class MF_BGK_Adve_Diff {       // The class
  public:
    MF_BGK_Adve_Diff(int RANK, int NP, MPI_Comm COMM);
    ~MF_BGK_Adve_Diff();

    void setParams(string filename);
    void ReadDomain();
    void outputParameters();
    void initialize();
    void run();
//    void evolve();
    void setCommf();

//    int getnEffectivePts(INT8* fImageH, int fNx, int fNy, int fNzH);
//    void setSparseDenseIndexMatrix(int fnEffecPoints, int* getSparseM, int *getDenseM,INT8* fImageH, int fNx, int fNy, int fNzH);
//    int getnEffectivePtsSingleSlice(INT8* fImageH, int zSlice, int fNx, int fNy);
//    void setSparseDenseIndexMatrixSingleSlice(int fnEffecPoints, int zSlice, int* getSparseM, int *getDenseM, INT8* fImageH, int fNx, int fNy);
    void   swap (   Float   **f,  Float   **fn );
//    void writeVtk(Float* vt, int tStep, char* filename);
//    void writeDomain(int tStep, char* filename);

    //test methods
//    void outputDomain();
//    void outputRaw(string filename,INT8* image, int startAddress, int imageSize);
    //void outputVtk(string filename,INT8* image, int startAddress, int imageSize);
    void check();

    void readBinaryData(float* vt,string filename, int sizeGM, int _NxNy);
    void call_evolveG();
    void call_setCommfG();
    void copy_Device2Host();
    void copy_Host2Device();

    void convertVelocity_Sparse2Dense();

    void getDispersionCoef();
    void getDissipateRate();



//    Utility *utility;
    IOhub *Agent_IO;
    Communicator *Agent_Comm;
    diffusionCoefficientAnalyzer *Analyzer_efft_DiffCo;

    int rank,nprocs;
    //input parameters
    map<string, string>Parameters;
    string job_id;
    int NX, NY, NZ;
    string inputImage, BUFF, dir_result;
    Float tau,rho;
    Float Fx,Fy,Fz;
    int Restart;
    int tStep;
    int timestepMax,timeVisualResult,timeAnalysis;
    Float Re,pixel_length,InletLayers,OutletLayers;
    int modifyDepth,BC;//BC: 0-periodic; 1-pressure; 2-velocity
    string ReadType;
    Float error;
    Float *errorArray,errorL;

    Float BC_rhoR, BC_rhoL;

    //G:Global; L:Local; H:Halo; M:Master; GD: GPU Device; S:Slave

    //double kv_W,kv_NW,dv_W,dv_NW;
    //Global parameters
    INT8 *domainGMH;
    int SizeGM,sizeGMH,NxNy,NxNy5;
    int *startNzAtDomainGMH,*startAddressAtDomainGMH;
    int nEffectivePtsTotal,  nEffectivePtsLS;
    int *dense2SparseIndexGM, *sparse2DenseIndexGM;
    int *startAddressAtTotalSparse;
    Float *uxT, *uyT, *uzT, *rhoT;//sparse

    //Local parameters
    INT8 *domainLSH;
    int *nNzSliceLS;
    int *sizeLS, *sizeLSH, PAD; // size is the product of Nz*Ny*Nx
    int *dense2SparseIndexLS, *sparse2DenseIndexLS;

    int nEdgeLow,nEdgeHigh,nHaloLow,nHaloHigh;//edge is a copy of the edge, halo is neighbor layer
    int nEdgeLow_PAD,nEdgeHigh_PAD,nHaloLow_PAD,nHaloHigh_PAD;//edge is a copy of the edge, halo is neighbor laye
    int *dense2SparseIndexCommEdgeLow, *sparse2DenseIndexCommEdgeLow;
    int *dense2SparseIndexCommEdgeHigh, *sparse2DenseIndexCommEdgeHigh;
    int *dense2SparseIndexCommHaloLow, *sparse2DenseIndexCommHaloLow;
    int *dense2SparseIndexCommHaloHigh, *sparse2DenseIndexCommHaloHigh;

    //int nCommOutLow,nCommOutHigh

    Float *uxL, *uyL, *uzL, *rhoL;//size, PAD
    Float *f, *fh;
    Float *fOutLowEdge, *fOutHighEdge, *fInLowHalo, *fInHighHalo;
    //|口|:
    //Float *rhoHaloOutR, *rhoHaloOutL,*rhoHaloInR, *rhoHaloInL;





    Float permeability;


    //Analysis section

    INT8 *domainReceiveForCheckGMH;
    int *nEffectivePts_subdomains;
    int *nEdgeLows, *nEdgeHighs,*nHaloLows, *nHaloHighs;

    //solute transport section
    Float *g, *gh;
    Float *gOutLowEdge, *gOutHighEdge, *gInLowHalo, *gInHighHalo;
    Float gtau,grho;
    Float BC_grhoR, BC_grhoL, grhoInject;
    int BC_dispersion;// 0  1 ?

    Float *grhoT, *grhoL, *scalarDissipateRate;
    float *grhoTdense, *scalarDissipateRateDense;

    int switch_useOutsideVelocity; //int ifUseOutsideVelocity;
    float *uxT_fromInput, *uyT_fromInput, *uzT_fromInput;
    float *uxL_fromInput, *uyL_fromInput, *uzL_fromInput;
    string uxOutsideName,uyOutsideName,uzOutsideName;
    void writeVtk_fromMatrixWithHalo(float* vt, int tStep, char* filename);
    //Float testvalue;

    // evaluate dispersion
    float  *probDens;
    float sigmaYY_Prev,sigmaYY_Curr, Dyy;
//    float firstMoments,secondMoments;
//    int timeInterval_effect_dispersion;



     float *CzProfile_PS; //ps - pore scale
     float momentOne, momentTwo;
     int rightBound,leftBound;
     float RaynoldsNumberScaleFactor;




    //CUDA variables
    string switch_CPU_GPU;

    int num_block ;
    int num_block_highEdge, num_block_lowEdge, PAD_edgeLow, PAD_edgeHigh;
    INT8 *domainLSHG;
    Float *fG, *fhG;
    Float *fOutLowEdgeG, *fOutHighEdgeG, *fInLowHaloG, *fInHighHaloG;
    Float *uxLG, *uyLG, *uzLG;
    Float *rhoLG;

    int *dense2SparseIndexLSG, *sparse2DenseIndexLSG;

    int *dense2SparseIndexCommHaloLowG, *dense2SparseIndexCommHaloHighG;
    int *sparse2DenseIndexCommEdgeLowG, *sparse2DenseIndexCommEdgeHighG;


    Float  *u_nG ;
    int  *nNzSliceLSG;


    Float *gG, *ghG;
    Float *gOutLowEdgeG, *gOutHighEdgeG, *gInLowHaloG, *gInHighHaloG;
    Float *grhoLG;

    float *uxL_fromInputG, *uyL_fromInputG, *uzL_fromInputG;





private:
    MPI_Comm comm;
    MPI_Status status;

    Float Cl, Cnu, Cden,Cu, Ct;

    Float viscosity_dynamic_lattice,viscosity_kinetic_lattice;
    Float density_phy, viscosity_dynamic_phy,viscosity_kinetic_phy;



};


