
#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;

typedef  char  INT8;
//typedef  int  INT8;

void ReadDomain(int length_Global, string inputImage,INT8* domain)
{
    
        
        ifstream myfile (inputImage, ios::in | ios::binary);
        if ( myfile.is_open() ) { // always check whether the file is open
            //myfile >> domain;
            myfile.read (domain, length_Global);
            cout<<"open"<<endl;
        }
    //"ddd" >> domain;
    //cout<<"open"<<endl;
    myfile.close();
  
}

void outputDomain( INT8* domain, int size)
{
     
        ofstream out("Cxxconvert.raw", ios::out | ios::binary);
        out.write (domain, size);
        //out<<domain;
       // out<<"abs";
        out.close();
 
}
int main(int argc, char** argv) {

    int length_globle = 30*15*10;
    INT8* domain;
    domain = (INT8*) malloc(length_globle*sizeof(INT8));
/*    for(int i = 0;i<length_globle;i++)
    {
        domain[i] = 97;
    }
*/
    ReadDomain(length_globle,"Poiseuille_TwoPlateOriginal.raw",domain);
    // Print off a hello world message
    cout << "length is " << length_globle<<" example is " << int(domain[200])<<endl;
    outputDomain(  domain, length_globle);


}
