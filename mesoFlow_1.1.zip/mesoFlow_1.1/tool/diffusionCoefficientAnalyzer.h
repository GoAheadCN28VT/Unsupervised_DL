#ifndef effectiveDiffusionCo_H
#define effectiveDiffusionCo_H


#include <iostream>
#include <fstream>

//#include <exception>
//#include <stdexcept>


#include <sstream>
#include <cstring>


using namespace std;

class diffusionCoefficientAnalyzer
{
    public:

    diffusionCoefficientAnalyzer(int _Nz);
    ~diffusionCoefficientAnalyzer();


    int Nx, Ny, Nz;
    float *CzProfile_PS; //ps - pore scale



    void getCzP_Moments_PS(float *CzProfile_PS_f, float *momentOne, float *momentTwo, int *left_bound, int *right_bound,
                                                        float * cmatrix, unsigned char *domainGMH, int *dense2SparseIndexGM, int _Nx, int _Ny, int _Nz);
    float getDyy(float sigmaYY_Curr, float sigmaYY_Prev,  int timeAnalysis);
    float getScalarDissipationRate( float *scalarDissipateRate,float * grhoT, float grho_truncate, unsigned char *domainGMH, int *dense2SparseIndexGM, int _Nx, int _Ny, int _Nz);



    void outputEffectDiffData( int tStep, string dir, float *cz_profile, int _nz, float moment_1st, float moment_2nd, float Dyy, int boundLeft, int boundRight, int tStepAna);

    void outputScalarDissipateRate( int tStep, string dir, float SDR);


//    void readParameters();





};


#endif
