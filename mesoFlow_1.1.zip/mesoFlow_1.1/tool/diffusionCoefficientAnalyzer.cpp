
#include <diffusionCoefficientAnalyzer.h>




diffusionCoefficientAnalyzer::diffusionCoefficientAnalyzer(int _Nz):Nz(_Nz){

  CzProfile_PS = (float*) malloc(Nz * sizeof(float));

}
diffusionCoefficientAnalyzer::~diffusionCoefficientAnalyzer(){

}


 void diffusionCoefficientAnalyzer::getCzP_Moments_PS(float *CzProfile_PS_f, float *momentOne, float *momentTwo, int *left_bound, int *right_bound,
                                                        float * cmatrix, unsigned char *domainGMH, int *dense2SparseIndexGM, int _Nx, int _Ny, int _Nz){

    int poreCount = 0;
    float soluteMass = 0.0;
    int j1,j2;
    int NxNy = _Nx * _Ny;

    float CavgZiSum = 0.0;
    float CavgSum = 0.0;
    float CavgMax = 0.0;

    float moment_1st = 0.0; // center of mass
    float moment_2nd = 0.0; // center of mass

    float factor = 0.01;
    int range_left, range_right;

//    *momentOne = 0.0;
//    *momentTwo = 0.0;

    for (int jz = 1; jz <= _Nz; jz++){
        poreCount = 0;
        soluteMass = 0.0;
        for (int jy = 0; jy < _Ny; jy++)
        for (int jx = 0; jx < _Nx; jx++) {
            j1 = jz * NxNy + jy * _Nx + jx;
            j2 = (jz - 1) * NxNy + jy * _Nx + jx;
            if (domainGMH[j1] != 0){
                poreCount += 1;
                soluteMass += cmatrix[dense2SparseIndexGM[j2]];
            }
        }
        CzProfile_PS_f[jz-1] = soluteMass / poreCount;
        CavgMax = CzProfile_PS_f[jz-1]>CavgMax? CzProfile_PS_f[jz-1]:CavgMax;
        CavgZiSum += CzProfile_PS_f[jz-1]  * (jz -1);
        CavgSum += CzProfile_PS_f[jz-1];
    }

    moment_1st =  CavgZiSum/CavgSum;

    for (int jz = 1; jz <= _Nz; jz++){

        moment_2nd += CzProfile_PS_f[jz-1] * (jz -1 - moment_1st)* (jz -1 - moment_1st);
//        *momentTwo += CzProfile_PS_f[jz-1] * (jz -1) * (jz -1);
        if (CzProfile_PS_f[jz-1] < CavgMax * factor && jz-1<moment_1st) {range_left = jz -1 ;}
        if (CzProfile_PS_f[_Nz - jz] < CavgMax * factor&& Nz - jz > moment_1st) {
        range_right = _Nz - jz;
//        cout<<CzProfile_PS_f[_Nz - jz] << " "<< CavgMax * factor << " "<< Nz - jz << " jz "<< jz<< endl;

        }
    }


    *momentOne = moment_1st;
    *momentTwo = moment_2nd/CavgSum;
    *left_bound = range_left;
    *right_bound = range_right;

 }

  float diffusionCoefficientAnalyzer::getScalarDissipationRate( float *scalarDissipateRate,float * grhoT, float grho_truncate, unsigned char *domainGMH, int *dense2SparseIndexGM, int _Nx, int _Ny, int _Nz){


    int j1,j2;
    int NxNy = _Nx * _Ny;
    int j1xP,j1xN,j1yP,j1yN,j1zP,j1zN;
    int j2xP,j2xN,j2yP,j2yN,j2zP,j2zN;

    float dc_x_neg, dc_x_pos, dc_y_neg, dc_y_pos, dc_z_neg, dc_z_pos;
    int dcIndex_XN, dcIndex_XP, dcIndex_YN, dcIndex_YP, dcIndex_ZN, dcIndex_ZP;
    int x_P, y_P, z_P, x_N, y_N, z_N;

    float DCT = 0.0;
    float DCi = 0.0;
    float DCx, DCy, DCz;

    for (int jz = 1; jz <= _Nz; jz++)
    for (int jy = 0; jy < _Ny; jy++)
    for (int jx = 0; jx < _Nx; jx++){
        j1 = jz * NxNy + jy * _Nx + jx;
        j2 = (jz - 1) * NxNy + jy * _Nx + jx;
        if (domainGMH[j1] != 0 ){
            if (grhoT[dense2SparseIndexGM[j2]] > grho_truncate) {
                DCi = 0.0;
                DCx = 0.0;
                DCy = 0.0;
                DCz = 0.0;


                x_P = (jx + 1) % _Nx;
                y_P = (jy + 1) % _Ny;
                z_P = jz + 1;
                x_N = _Nx - (_Nx - jx) % _Nx - 1;
                y_N = _Ny - (_Ny - jy) % _Ny - 1;
                z_N = jz - 1;

                dcIndex_XN = 1;
                dcIndex_XP = 1;
                dcIndex_YN = 1;
                dcIndex_YP = 1;
                dcIndex_ZN = 1;
                dcIndex_ZP = 1;

                if (jx == 0)       {dcIndex_XN = 0; }
                if (jx == _Nx - 1) {dcIndex_XP = 0; }
                if (jy == 0)       {dcIndex_YN = 0; }
                if (jy == _Ny - 1) {dcIndex_YP = 0; }
                if (jz == 1)       {dcIndex_ZN = 0; z_N = jz;}
                if (jz == _Nz)     {dcIndex_ZP = 0; z_P = jz;}


                j1xP = jz * NxNy + jy * _Nx + x_P;
                j1xN = jz * NxNy + jy * _Nx + x_N;
                j1yP = jz * NxNy + y_P * _Nx + jx;
                j1yN = jz * NxNy + y_N * _Nx + jx;
                j1zP = z_P * NxNy + jy * _Nx + jx;
                j1zN = z_N * NxNy + jy * _Nx + jx;

                j2xP = (jz - 1) * NxNy + jy * _Nx + x_P;
                j2xN = (jz - 1)* NxNy + jy * _Nx + x_N;
                j2yP = (jz - 1) * NxNy + y_P * _Nx + jx;
                j2yN = (jz - 1)* NxNy + y_N * _Nx + jx;
                j2zP = (z_P - 1) * NxNy + jy * _Nx + jx;
                j2zN = (z_N - 1) * NxNy + jy * _Nx + jx;

                if (domainGMH[j1xN] == 0) { dcIndex_XN = 0; }
                if (domainGMH[j1xP] == 0) { dcIndex_XP = 0; }
                if (domainGMH[j1yN] == 0) { dcIndex_YN = 0; }
                if (domainGMH[j1yP] == 0) { dcIndex_YP = 0; }
                if (domainGMH[j1zN] == 0) { dcIndex_ZN = 0; }
                if (domainGMH[j1zP] == 0) { dcIndex_ZP = 0; }

                dc_x_neg = grhoT[dense2SparseIndexGM[j2]]   - grhoT[dense2SparseIndexGM[j2xN]];
                dc_x_pos = grhoT[dense2SparseIndexGM[j2xP]] - grhoT[dense2SparseIndexGM[j2]];
                dc_y_neg = grhoT[dense2SparseIndexGM[j2]]   - grhoT[dense2SparseIndexGM[j2yN]];
                dc_y_pos = grhoT[dense2SparseIndexGM[j2yP]] - grhoT[dense2SparseIndexGM[j2]];
                dc_z_neg = grhoT[dense2SparseIndexGM[j2]]   - grhoT[dense2SparseIndexGM[j2zN]];
                dc_z_pos = grhoT[dense2SparseIndexGM[j2zP]] - grhoT[dense2SparseIndexGM[j2]];


                if (dcIndex_XN == 1 || dcIndex_XP == 1) {DCx = ( dc_x_neg * dcIndex_XN + dc_x_pos * dcIndex_XP)/(dcIndex_XN + dcIndex_XP);} else {DCx = 0;}
                if (dcIndex_YN == 1 || dcIndex_YP == 1) {DCy = ( dc_y_neg * dcIndex_YN + dc_y_pos * dcIndex_YP)/(dcIndex_YN + dcIndex_YP);} else {DCy = 0;}
                if (dcIndex_ZN == 1 || dcIndex_ZP == 1) {DCz = ( dc_z_neg * dcIndex_ZN + dc_z_pos * dcIndex_ZP)/(dcIndex_ZN + dcIndex_ZP);} else {DCz = 0;}
                DCi =  DCx * DCx + DCy * DCy + DCz * DCz;

            }
            else {
                DCi = 0.0;
            }
            DCT += DCi;
            scalarDissipateRate[dense2SparseIndexGM[j2]] = DCi;

        }//if domainGMH
    }// three for

    return DCT;
 }


 float diffusionCoefficientAnalyzer::getDyy(float sigmaYY_Curr, float sigmaYY_Prev,   int timeAnalysis){
    float Dyy = 0.0;
    return Dyy = 0.5 * (sigmaYY_Curr - sigmaYY_Prev)/ timeAnalysis;

 }


  void diffusionCoefficientAnalyzer::outputEffectDiffData( int tStep, string dir, float *cz_profile, int _nz, float moment_1st, float moment_2nd, float Dyy, int boundLeft, int boundRight, int tStepAna){

    if (tStep == tStepAna){
        ofstream out(dir + "_dispersionAnalysis.csv");
        out<<"timestep moment_1st moment_2nd Dyy b_tail b_front"<<endl;
        out.close();

//        ofstream out_cz(dir + "czProfiles.dat");
//
//        out_cz.close();
    }


    ofstream out;
    out.open(dir+"_dispersionAnalysis.csv",ios::app);
    out << tStep << " "<< moment_1st << " "<< moment_2nd << " "<< Dyy << " " <<boundLeft << " "<< boundRight<< endl;
    out.close();

    ofstream out_cz;
    out_cz.open(dir+"_czProfiles.dat",ios::app);
    out_cz << tStep;
    for (int iz = 0; iz < _nz; iz ++){
        out_cz<< " "<< cz_profile[iz];
    }
    out_cz<< endl;
    out_cz.close();

  }



  void diffusionCoefficientAnalyzer::outputScalarDissipateRate( int tStep, string dir, float SDR){
    ofstream out;
    out.open(dir+"_scalarDissipateRate.dat",ios::app);
    out << tStep << " "<< SDR  << endl;
    out.close();
  }


