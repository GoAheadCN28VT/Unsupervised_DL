#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <iostream>
#include <exception>
#include <stdexcept>
#include <fstream>
#include <mpi.h>
//#include <lbm.h>
#include <sstream>
#include <cmath>
#include <cstring>
#include <map>

#define  blockDim_x       64

#define TAG_domain     1
//#define TAG_f     2
#define TAG_ux     3
#define TAG_uy     4
#define TAG_uz     5
#define TAG_uu     6
#define TAG_rho    7

#define TAG_fnw     11
#define TAG_fw      12
#define TAG_rho_nw  13
#define TAG_rho_w   14
#define TAG_phaseField   15

#define TAG_Index  100
#define TAG_analysis     101


#define TAG_t1    111
#define TAG_t2    112
#define TAG_t3    113
#define TAG_t4    114

using namespace std;
//                     0  1  2   3  4  5  6  7  8  9   10  11  12 13 14  15 16 17 18
const double ex[19] = { 0, 1, -1, 0, 0, 0, 0, 1, 1, -1, -1, 1, -1, 1, -1, 0, 0, 0, 0 };
const double ey[19] = { 0, 0, 0, 1, -1, 0, 0, 1, -1, 1, -1, 0,  0, 0,  0, 1, 1, -1, -1 };
const double ez[19] = { 0, 0, 0, 0, 0, 1, -1, 0, 0,  0,  0, 1,  1,-1, -1, 1,-1, 1, -1 };



const double one = 1.0;
const double three = 3.0;
const double inv3 = 1.0/3;
const double inv18 = 1.0/18;
const double inv36 = 1.0/36;
const double fourpt5 = 4.5;
const double onept5 = 1.5;
const double c_squinv = 3.0;
const double angle2arc=3.14159265/180.0;
const double rsqinv=1.0/sqrt(2.0);
const double rsq=sqrt(2.0);

__constant__  double exG[19] = { 0, 1, -1, 0, 0, 0, 0, 1, 1, -1, -1, 1, -1, 1, -1, 0, 0, 0, 0 };
__constant__  double eyG[19] = { 0, 0, 0, 1, -1, 0, 0, 1, -1, 1, -1, 0,  0, 0,  0, 1, 1, -1, -1 };
__constant__  double ezG[19] = { 0, 0, 0, 0, 0, 1, -1, 0, 0,  0,  0, 1,  1,-1, -1, 1,-1, 1, -1 };
__constant__ double rsqinvG = 1.0/1.41421356237;

class MP_ColorGradient {       // The class
  public:
    MP_ColorGradient(int RANK, int NP, MPI_Comm COMM);
    ~MP_ColorGradient();

    void setParams(string filename);
    void ReadDomain();
    void initialize();
    void evolveStageOne();
    void setCommRho();
    void evolveStageTwo();
    void swap (double **f, double **fn);
    void setCommf();
    void run();
    void outputParameters();
    void simulationLog();

    int getnEffectivePts(unsigned char* fImageH, int fNx, int fNy, int fNzH);
    void setSparseDenseIndexMatrix(int fnEffecPoints, int* getSparseM, int *getDenseM,unsigned char* fImageH, int fNx, int fNy, int fNzH);
    int getnEffectivePtsSingleSlice(unsigned char* fImageH, int zSlice, int fNx, int fNy);
    void setSparseDenseIndexMatrixSingleSlice(int fnEffecPoints, int zSlice, int* getSparseM, int *getDenseM, unsigned char* fImageH, int fNx, int fNy);

    void writeWettabilityVtk(char* filename);
    void writeVtk(double* vt, int tStep, char* filename);
    void writeDomain(int tStep, char* filename);
    void writeRawUint8( char* filename);
    void write_uint8_phaseConfigure(double* vt, int tStep, char* filename);
    void write_float_velocity(float* vt, int tStep, char* filename);
    void analytical_sol(int ly,double aa1, double ftaunw, double ftauw, double frhonw, double frhow, double df);
    void outputUzProfile();


    void convertVelocityDouble2Float();
    void assemble_uu();
    void getPorosity();
    void getVolInject();


    void copy_Device2Host_fout();
    void copy_Host2Device_fin();
    void copy_Host2Device_rhoin();
    void copy_Device2Host_rhototal();
    void call_evolveStageOneG();
    void call_evolveStageTwoG();
    void setCommRho_cpyCuda2Host();
    void call_setCommfG();


//    void evolveStageOne_stream();
//    void evolveStageOne_colision();


    int rank,nprocs;
    //input parameters
    string job_id;
    string switch_CPU_GPU;

    int NX, NY, NZ, NZo;
    string inputImage, dir_result, BUFF;
    int tStep;

    double tauNW,tauW,rhoNWi,rhoWi,beta;
    double Fx,Fy,Fz;
    double A;


    int Restart,visualVelocity;

    int timestepMax,timeIntervalAnalysis,timeIntervalResult;/////////////
    double Ca;

    map<string, string>Parameters;

    //string ReadType;
    int BC;
    double BC_rhoL,BC_rhoR;
    int BC_colorL,BC_colorR;

    double velocityInlet;


    int InletBufferLayers, OutletBufferLayers;
    int InletBufferLayersColor, OutletBufferLayersColor;

    //Global parameters
    unsigned char *domainGMH;
    int sizeGMo,SizeGM,sizeGMH,NxNy,NxNy5;
    int *startNzAtDomainGMH,*startAddressAtDomainGMH;
    int nEffectivePtsTotal,  nEffectivePtsLS;
    int *dense2SparseIndexGM, *sparse2DenseIndexGM;
    int *startAddressAtTotalSparse;
    double *uxT, *uyT, *uzT, *uuT, *rhoT, *phaseFieldT;//sparse

    //Local paremeters
    unsigned char *domainLSH, *contactAngleLSH;
    int *nNzSliceLS;
    int *sizeLS, *sizeLSH, PAD; // size is the product of Nz*Ny*Nx
    int *dense2SparseIndexLS, *sparse2DenseIndexLS;

    int nEdgeLow,nEdgeHigh,nHaloLow,nHaloHigh;//edge is a copy of the edge, halo is neighbor layer
    int *dense2SparseIndexCommEdgeLow, *sparse2DenseIndexCommEdgeLow;
    int *dense2SparseIndexCommEdgeHigh, *sparse2DenseIndexCommEdgeHigh;
    int *dense2SparseIndexCommHaloLow, *sparse2DenseIndexCommHaloLow;
    int *dense2SparseIndexCommHaloHigh, *sparse2DenseIndexCommHaloHigh;

    double *uxL, *uyL, *uzL,*uuL, *rhoNWL, *rhoWL, *phaseFieldL;//size, PAD
    double *fnw, *fw, *ff, *fnwh, *fwh;
    double *fnwOutLowEdge, *fnwOutHighEdge, *fnwInLowHalo, *fnwInHighHalo;
    double *fwOutLowEdge, *fwOutHighEdge, *fwInLowHalo, *fwInHighHalo;
    double *rhonwOutLowEdge, *rhonwOutHighEdge, *rhonwInLowHalo, *rhonwInHighHalo;
    double *rhowOutLowEdge, *rhowOutHighEdge, *rhowInLowHalo, *rhowInHighHalo;

    //Results
    int vol_pore, vol_w;
    double PermNW,PermW,porosity, saturation,errPerm;
    double kv_W,kv_NW,dv_W,dv_NW;
    double vol_inject;


    //Analysis section
    unsigned char *domainReceiveForCheckGMH;
    int *nEffectivePts_subdomains;
    int *nEdgeLows, *nEdgeHighs,*nHaloLows, *nHaloHighs;

    float *uxTf, *uyTf, *uzTf;
    double pixel_length,characteristic_length_lattice;

    //CUDA variables
    int num_block ;
    int num_block_highEdge, num_block_lowEdge, PAD_edgeLow, PAD_edgeHigh;

    unsigned char *domainLSHG;
    int *dense2SparseIndexLSG, *sparse2DenseIndexLSG;
    int *dense2SparseIndexCommHaloLowG, *dense2SparseIndexCommHaloHighG;
    int *sparse2DenseIndexCommEdgeLowG, *sparse2DenseIndexCommEdgeHighG;

    double *fnwG, *fnwhG, *fwG, *fwhG, *ffG;
    double *fnwOutLowEdgeG, *fnwOutHighEdgeG, *fnwInLowHaloG, *fnwInHighHaloG;
    double *fwOutLowEdgeG, *fwOutHighEdgeG, *fwInLowHaloG, *fwInHighHaloG;


    double *rhonwOutLowEdgeG, *rhonwOutHighEdgeG, *rhonwInLowHaloG, *rhonwInHighHaloG;
    double *rhowOutLowEdgeG, *rhowOutHighEdgeG, *rhowInLowHaloG, *rhowInHighHaloG;



    double *uxLG, *uyLG, *uzLG;
    double *rhoNWLG, *rhoWLG, *phaseFieldLG;




    double  *u_nG ;
    int  *nNzSliceLSG;


    double *fnw_afterstream, *fw_afterstream;
    double *fnw_afterstreamG, *fw_afterstreamG;


private:
    MPI_Comm comm;
    MPI_Status status;
};


