#include <iostream>
#include <fstream>

//#include <exception>
//#include <stdexcept>


#include <sstream>
#include <cstring>
#include <map>

using namespace std;

class DataRader
{
    public:

    DataRader(string _filename);
    ~DataRader();



    void readParameters();


    string filename;
    map<string, string>Parameters;


};
