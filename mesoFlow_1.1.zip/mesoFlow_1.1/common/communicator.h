#ifndef communicator_H
#define communicator_H



#include <mm_malloc.h>
#include <mpi.h>

#include <sstream>
#include <cstring>
#include <map>

using namespace std;

extern void COMM_AllocateMemory_zeroCpy(void **address, size_t size);

class Communicator
{
    public:

    Communicator();
    ~Communicator();
    int getnEffectivePts_imageHalo(unsigned char* fImageH, int fNx, int fNy, int fNzH);
    int getnEffectivePtsSingleSlice_imageHalo(unsigned char* fImageH, int zSlice, int fNx, int fNy);
    void setSparseDenseIndexMatrix( int* getSparseM, int *getDenseM, unsigned char* fImageH, int fnEffecPoints, int fNx, int fNy, int fNzH, int rank);
    void setSparseDenseIndexMatrixSingleSlice(int* getSparseM, int *getDenseM, unsigned char* fImageH, int fnEffecPoints,  int fNx, int fNy, int zSlice, int rank);


//    void COMM_sendrecv(int rank, int nprocs, int *sendBuff, int sendCount, int *recvBuff, int recvCount,MPI_Comm comm,MPI_Status *status);
    void assembleVariable_slave2master(float * uuT, float *uuL,
        int rank, int nprocs,  int nEffectivePtsLS, int *startAddressAtTotalSparse, int *nEffectivePts_subdomains, int TAG_uu,  MPI_Comm comm,  MPI_Status *status );

    void  CommuniateEdgeHalo(int rank, int nprocs, float *fOutHighEdge, float *fOutLowEdge, float *fInLowHalo, float *fInHighHalo, int nEdgeLow, int nEdgeHigh ,int nHaloLow, int nHaloHigh ,
                        int TAG_f, MPI_Comm comm,  MPI_Status *status );

    string filename;



};



#endif
