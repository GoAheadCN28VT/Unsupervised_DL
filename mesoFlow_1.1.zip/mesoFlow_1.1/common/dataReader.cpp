
#include <dataReader.h>




DataRader::DataRader(string _filename):
filename(_filename){

}
DataRader::~DataRader(){

}


void DataRader::readParameters(){
    ifstream in;
    string line;
    istringstream iss;
    string str1;
    string str2;

    in.open(filename);
    while(in.good()){
        getline(in,line);
        iss.clear();
        str1 = " ";
        str2 = " ";
        iss.str(line);
        iss >> str1;
        str1.erase(str1.end()-1);
        iss >> str2;
        Parameters[str1] = str2;
    }//while
    in.close();
}






