#ifndef facility_H
#define facility_H
//#include <exception>
//#include <stdexcept>


#include <sstream>
#include <cstring>
#include <map>

using namespace std;

extern void setDevice(int rank, int nprocs, int * numGPUs );

class Facility
{
    public:

    Facility();
    ~Facility();





    string filename;



};



#endif
