
#include <communicator.h>






Communicator::Communicator(){

}
Communicator::~Communicator(){

}



int Communicator::getnEffectivePts_imageHalo(unsigned char* fImageH, int fNx, int fNy, int fNzH){
    int fipNeighbor,fxNeighbor,fyNeighbor,fzNeighbor;
    int fnPositivePoints = 0;
    const int fNxNy = fNx * fNy;
    bool fIfEffective = false;

    //If the total sparse matrix can be caled here?

    for (int iz = 1; iz < fNzH - 1; iz++)
    for (int iy = 0; iy < fNy; iy++)
    for (int ix = 0; ix < fNx; ix++) {
        for (int izz = -1; izz <= 1; izz++)
        for (int iyy = -1; iyy <= 1; iyy++)
        for (int ixx = -1; ixx <= 1; ixx++) {
            fxNeighbor = ix + ixx;
            if (ix + ixx == -1) {fxNeighbor = fNx-1; }
            else if (ix + ixx == fNx){fxNeighbor = 0; }

            fyNeighbor = iy + iyy;
            if (iy + iyy == -1) {fyNeighbor = fNy-1; }
            else if (iy + iyy == fNy){fyNeighbor = 0; }

            fzNeighbor = iz+izz;

            fipNeighbor = fzNeighbor * fNxNy + fyNeighbor * fNx + fxNeighbor;
            if (fImageH[fipNeighbor] > 0) {fIfEffective = true;}
        }

        if (fIfEffective == true){
            fnPositivePoints += 1;
            fIfEffective = false;
        }
    }
    return fnPositivePoints;
}

int Communicator::getnEffectivePtsSingleSlice_imageHalo(unsigned char* fImageH, int zSlice, int fNx, int fNy){
    int fipNeighbor,fxNeighbor,fyNeighbor,fzNeighbor;
    int fnPositivePoints = 0;
    const int fNxNy = fNx * fNy;
    bool fIfEffective = false;

    //If the total sparse matrix can be caled here?

    int iz = zSlice;
    for (int iy = 0; iy < fNy; iy++)
    for (int ix = 0; ix < fNx; ix++) {
        for (int izz = -1; izz <= 1; izz++)
        for (int iyy = -1; iyy <= 1; iyy++)
        for (int ixx = -1; ixx <= 1; ixx++) {
            fxNeighbor = ix + ixx;
            if (ix + ixx == -1) {fxNeighbor = fNx-1; }
            else if (ix + ixx == fNx){fxNeighbor = 0; }

            fyNeighbor = iy + iyy;
            if (iy + iyy == -1) {fyNeighbor = fNy-1; }
            else if (iy + iyy == fNy){fyNeighbor = 0; }

            fzNeighbor = iz+izz;

            fipNeighbor = fzNeighbor * fNxNy + fyNeighbor * fNx + fxNeighbor;
            if (fImageH[fipNeighbor] > 0) {fIfEffective = true;}
        }

        if (fIfEffective == true){
            fnPositivePoints += 1;
            fIfEffective = false;
        }
    }
    return fnPositivePoints;
}

void Communicator::setSparseDenseIndexMatrix( int* getSparseM, int *getDenseM, unsigned char* fImageH, int fnEffecPoints, int fNx, int fNy, int fNzH, int rank){
    int fipNeighbor,fxNeighbor,fyNeighbor,fzNeighbor;
    int fiSparseCount = 0;
    const int fNxNy = fNx * fNy;
    bool fIfEffective = false;
    int ip = 0;

    //If the total sparse matrix can be caled here?

    for (int iz = 1; iz < fNzH - 1; iz++)
    for (int iy = 0; iy < fNy; iy++)
    for (int ix = 0; ix < fNx; ix++) {
        ip = (iz-1) * fNxNy + iy * fNx   + ix;
        for (int izz = -1; izz <= 1; izz++)
        for (int iyy = -1; iyy <= 1; iyy++)
        for (int ixx = -1; ixx <= 1; ixx++) {
            fxNeighbor = ix + ixx;
            if (ix + ixx == -1) {fxNeighbor = fNx-1; }
            else if (ix + ixx == fNx){fxNeighbor = 0; }

            fyNeighbor = iy + iyy;
            if (iy + iyy == -1) {fyNeighbor = fNy-1; }
            else if (iy + iyy == fNy){fyNeighbor = 0; }

            fzNeighbor = iz+izz;

            fipNeighbor = fzNeighbor * fNxNy + fyNeighbor * fNx + fxNeighbor;
            if (fImageH[fipNeighbor] > 0) {fIfEffective = true;}
        }

        if (fIfEffective == true){
            getSparseM[ip] = fiSparseCount;
            getDenseM[fiSparseCount]=ip;
            fiSparseCount += 1;
            fIfEffective = false;
        }
        else{
            getSparseM[ip] = fnEffecPoints-1;
        }
    }
    if (fiSparseCount != fnEffecPoints){ cout <<"rank"<< rank << ", fnEffectivePoints count error!"; exit(2);}
}

void Communicator::assembleVariable_slave2master(float * uuT, float *uuL,
        int rank, int nprocs,  int nEffectivePtsLS, int *startAddressAtTotalSparse, int *nEffectivePts_subdomains, int TAG_uu,  MPI_Comm comm,  MPI_Status *status ){

    if(rank > 0){        MPI_Send(uuL, nEffectivePtsLS, MPI_FLOAT, 0, TAG_uu, comm);  }
    if(rank == 0){
        memcpy(&uuT[0], &uuL[0], nEffectivePtsLS * sizeof(float));
        for (int i = 1; i < nprocs; i++){ MPI_Recv(&uuT[startAddressAtTotalSparse[i]], nEffectivePts_subdomains[i], MPI_FLOAT, i, TAG_uu, comm, status);}
    }
}

void Communicator::setSparseDenseIndexMatrixSingleSlice(int* getSparseM, int *getDenseM, unsigned char* fImageH, int fnEffecPoints,  int fNx, int fNy, int zSlice, int rank){
    int fipNeighbor,fxNeighbor,fyNeighbor,fzNeighbor;
    int fiSparseCount = 0;
    const int fNxNy = fNx * fNy;
    bool fIfEffective = false;
    int ip = 0;

    //If the total sparse matrix can be caled here?

    int iz = zSlice;
    for (int iy = 0; iy < fNy; iy++)
    for (int ix = 0; ix < fNx; ix++) {
        ip = iy * fNx + ix;// check this line

        for (int izz = -1; izz <= 1; izz++)
        for (int iyy = -1; iyy <= 1; iyy++)
        for (int ixx = -1; ixx <= 1; ixx++) {
            fxNeighbor = ix + ixx;
            if (ix + ixx == -1) {fxNeighbor = fNx-1; }
            else if (ix + ixx == fNx){fxNeighbor = 0; }

            fyNeighbor = iy + iyy;
            if (iy + iyy == -1) {fyNeighbor = fNy-1; }
            else if (iy + iyy == fNy){fyNeighbor = 0; }

            fzNeighbor = iz+izz;

            fipNeighbor = fzNeighbor * fNxNy + fyNeighbor * fNx + fxNeighbor;
            if (fImageH[fipNeighbor] > 0) {fIfEffective = true;}
        }

        if (fIfEffective == true){
            getSparseM[ip] = fiSparseCount;
            getDenseM[fiSparseCount] = ip;
            fiSparseCount += 1;
            fIfEffective = false;
        }
        else{
            getSparseM[ip] = fnEffecPoints-1;
        }
    }
    if (fiSparseCount != fnEffecPoints){ cout <<"rank"<< rank << ", fnEffectivePoints count error!"; exit(2);}
}


void  Communicator::CommuniateEdgeHalo(int rank, int nprocs, float *fOutHighEdge, float *fOutLowEdge, float *fInLowHalo, float *fInHighHalo, int nEdgeLow, int nEdgeHigh ,int nHaloLow, int nHaloHigh ,
                        int TAG_f, MPI_Comm comm,  MPI_Status *status ){
    int left, right;
    if (rank > 0) {left = rank - 1;}    else {left = MPI_PROC_NULL;}
    if (rank < nprocs-1) {right = rank + 1;}    else {right = MPI_PROC_NULL;}
    // data left >>>> right
    MPI_Sendrecv(fOutHighEdge, nEdgeHigh * 5, MPI_FLOAT, right, TAG_f, fInLowHalo, nHaloLow * 5, MPI_FLOAT, left, TAG_f,  MPI_COMM_WORLD, status);
    //data  left<--right
    MPI_Sendrecv(fOutLowEdge,  nEdgeLow * 5,  MPI_FLOAT, left, TAG_f, fInHighHalo, nHaloHigh * 5, MPI_FLOAT, right,TAG_f,  MPI_COMM_WORLD,status);
    //Periodic
    if (rank == 0){
        left = nprocs - 1;
        MPI_Send(fOutLowEdge, nEdgeLow * 5, MPI_FLOAT, left, TAG_f, MPI_COMM_WORLD);
        MPI_Recv(fInLowHalo,  nHaloLow * 5, MPI_FLOAT, left, TAG_f, MPI_COMM_WORLD, status);
    }
    if (rank == nprocs - 1)    {
        right = 0;
        MPI_Recv(fInHighHalo, nHaloHigh * 5, MPI_FLOAT, right, TAG_f, MPI_COMM_WORLD, status);
        MPI_Send(fOutHighEdge,nEdgeHigh * 5, MPI_FLOAT, right, TAG_f, MPI_COMM_WORLD);
    }
}

