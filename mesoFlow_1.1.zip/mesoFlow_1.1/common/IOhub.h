#ifndef IOhub_H
#define IOhub_H


#include <iostream>
#include <fstream>

//#include <exception>
//#include <stdexcept>


#include <sstream>
#include <cstring>

using namespace std;

class IOhub
{


    public:


    void ReadDomain2imgH( string source_inputImage, unsigned char *dest_domainGMH, int start_NxNy, int sizeGM);
    void writeBinary(float* vt, int start, int length, string dir_dest, string filename, int tag);
    void writeVtk_sparse_Physical_3D(float* vt, float Cu, int _Nx, int _Ny, int _Nz, unsigned char *domainGMH, int *dense2SparseIndexGM, string nameVariable, string dirName, string fileName, int tStep);

//    template<typename T>
    void writeVtk_ExcludeHalo_3D(unsigned char *Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);
    void writeVtk_ExcludeHalo_3D(float *Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);

    void writeVtk_dense_Physical_3D(float *Vara, float Cu, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);
    void writeVtk_dense_Physical_3D(double *Vara, float Cu, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep);



};



#endif
