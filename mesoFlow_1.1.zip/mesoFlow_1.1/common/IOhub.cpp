
#include <IOhub.h>



void IOhub::ReadDomain2imgH( string source_inputImage, unsigned char *dest_domainGMH, int start_NxNy, int sizeGM)
{


        ifstream sourcefile (source_inputImage, ios::in | ios::binary);
        if ( sourcefile.is_open() ) { // always check whether the file is open
            sourcefile.read ((char *)&dest_domainGMH[start_NxNy], sizeGM);
        }
        sourcefile.close();
}



void IOhub::writeBinary(float* vt, int start, int length, string dir_dest, string filename, int tag){

    ostringstream name;
    name << dir_dest << filename << "_" << tag << ".raw";
    ofstream out;
    out.open(name.str().c_str(),  ios::binary);
    out.write((char *)&vt[start],length); //length = size * sizeof(float || int || double)
    out.close();
}

    void IOhub:: writeVtk_sparse_Physical_3D(float* vt, float Cu, int _Nx, int _Ny, int _Nz, unsigned char *domainGMH, int *dense2SparseIndexGM, string nameVariable, string dirName, string fileName, int tStep)
    { // input: vt without halo, ordered by a spase index matrix. The value on solid space are set as 0.0 according to domain map - domainGMH
        int   jx, jy, jz,j1,j2;
        int _NxNy = _Nx * _Ny;
        int _sizeGM = _NxNy * _Nz;

        ostringstream name;
        name << dirName << fileName << "_" << tStep << "ts" << ".vtk";
        ofstream out(name.str().c_str());

        out << "# vtk DataFile Version 2.0 " << endl;
        out << "MesoFlow by RG " << endl;
        out << "ASCII " << endl << endl;

        out << "DATASET STRUCTURED_POINTS " << endl;
        out << "DIMENSIONS  " << _Nx << " " << _Ny << " " << _Nz << endl;
        out << "ORIGIN    " << 0 << " " << 0 << " " << 0 << endl;
        out << "SPACING    " << 1.0 << " " << 1.0 << " " << 1.0 << endl << endl;

        out << "POINT_DATA    " << _sizeGM << endl << endl;

        out << "SCALARS " << nameVariable << " float" << endl;
        out << "LOOKUP_TABLE default" << endl;

        if (Cu == 1.0){
            for (jz = 1; jz <= _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                j2 = (jz-1) * _NxNy + jy * _Nx + jx;
                if (domainGMH[j1] != 0){  out << (float)vt[dense2SparseIndexGM[j2]] << endl; }
                else { out << 0.0 << endl; }
            }
        }
        else{
            for (jz = 1; jz <= _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                j2 = (jz-1) * _NxNy + jy * _Nx + jx;
                if (domainGMH[j1] != 0){  out << (float)vt[dense2SparseIndexGM[j2]] * Cu << endl;  }
                else { out << 0.0 << endl; }
            }
        }
        out.close();
}

//template<typename T>
void IOhub:: writeVtk_ExcludeHalo_3D(unsigned char *Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep)
{// input: vt is a matrix with halo.
  // the output excludes the halo layers. the solid space are set as 0.0
        int   jx, jy, jz, j1;
        int _NxNy = _Nx * _Ny;
        int _sizeGM = _NxNy * _Nz;

        ostringstream name;
    //    name << filename << "_" << tStep << "ts" << ".vtk";
        name << dirName << fileName << "_" << tStep << "ts" << ".vtk";
        ofstream out(name.str().c_str());

        out << "# vtk DataFile Version 2.0 " << endl;
        out << "LBM by Guo " << endl;
        out << "ASCII " << endl << endl;

        out << "DATASET STRUCTURED_POINTS " << endl;
        out << "DIMENSIONS  " << _Nx << " " << _Ny << " " << _Nz << endl;
        out << "ORIGIN    " << 0 << " " << 0 << " " << 0 << endl;
        out << "SPACING    " << 1.0 << " " << 1.0 << " " << 1.0 << endl << endl;

        out << "POINT_DATA    " << _sizeGM << endl << endl;

        out << "SCALARS " << nameVariable << " float" << endl;
        out << "LOOKUP_TABLE default" << endl;

        //out.write(vt,NX * NY*NZ);
        for (jz = 1; jz <= _Nz; jz++)
        for (jy = 0; jy < _Ny; jy++)
        for (jx = 0; jx < _Nx; jx++) {
            j1 = jz * _NxNy + jy * _Nx + jx;
            out << (float)Vara[j1] << endl;
        }

    out.close();
}



void IOhub:: writeVtk_ExcludeHalo_3D(float *Vara, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep)
{// input: vt is a matrix with halo.
  // the output excludes the halo layers. the solid space are set as 0.0
        int   jx, jy, jz, j1;
        int _NxNy = _Nx * _Ny;
        int _sizeGM = _NxNy * _Nz;

        ostringstream name;
    //    name << filename << "_" << tStep << "ts" << ".vtk";
        name << dirName << fileName << "_" << tStep << "ts" << ".vtk";
        ofstream out(name.str().c_str());

        out << "# vtk DataFile Version 2.0 " << endl;
        out << "LBM by Guo " << endl;
        out << "ASCII " << endl << endl;

        out << "DATASET STRUCTURED_POINTS " << endl;
        out << "DIMENSIONS  " << _Nx << " " << _Ny << " " << _Nz << endl;
        out << "ORIGIN    " << 0 << " " << 0 << " " << 0 << endl;
        out << "SPACING    " << 1.0 << " " << 1.0 << " " << 1.0 << endl << endl;

        out << "POINT_DATA    " << _sizeGM << endl << endl;

        out << "SCALARS " << nameVariable << " float" << endl;
        out << "LOOKUP_TABLE default" << endl;

        //out.write(vt,NX * NY*NZ);
        for (jz = 1; jz <= _Nz; jz++)
        for (jy = 0; jy < _Ny; jy++)
        for (jx = 0; jx < _Nx; jx++) {
            j1 = jz * _NxNy + jy * _Nx + jx;
            out << (float)Vara[j1] << endl;


        }

    out.close();
}

void IOhub:: writeVtk_dense_Physical_3D(float *Vara, float Cu, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep)
{// input: vt is a matrix with halo.
  // the output excludes the halo layers. the solid space are set as 0.0
        int   jx, jy, jz, j1;
        int _NxNy = _Nx * _Ny;
        int _sizeGM = _NxNy * _Nz;

        ostringstream name;
    //    name << filename << "_" << tStep << "ts" << ".vtk";
        name << dirName << fileName << "_" << tStep << "ts" << ".vtk";
        ofstream out(name.str().c_str());

        out << "# vtk DataFile Version 2.0 " << endl;
        out << "LBM by Guo " << endl;
        out << "ASCII " << endl << endl;

        out << "DATASET STRUCTURED_POINTS " << endl;
        out << "DIMENSIONS  " << _Nx << " " << _Ny << " " << _Nz << endl;
        out << "ORIGIN    " << 0 << " " << 0 << " " << 0 << endl;
        out << "SPACING    " << 1.0 << " " << 1.0 << " " << 1.0 << endl << endl;

        out << "POINT_DATA    " << _sizeGM << endl << endl;

        out << "SCALARS " << nameVariable << " float" << endl;
        out << "LOOKUP_TABLE default" << endl;

        if (Cu == 1.0){
            for (jz = 0; jz < _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                out << Vara[j1] << endl;
            }
        }
        else {
            for (jz = 0; jz < _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                out << Vara[j1] * Cu  << endl;
            }
        }
    out.close();
}


void IOhub:: writeVtk_dense_Physical_3D(double *Vara,  float Cu, int _Nx, int _Ny, int _Nz,string nameVariable, string dirName, string fileName, int tStep)
{// input: vt is a matrix with halo.
  // the output excludes the halo layers. the solid space are set as 0.0
        int   jx, jy, jz, j1;
        int _NxNy = _Nx * _Ny;
        int _sizeGM = _NxNy * _Nz;

        ostringstream name;
    //    name << filename << "_" << tStep << "ts" << ".vtk";
        name << dirName << fileName << "_" << tStep << "ts" << ".vtk";
        ofstream out(name.str().c_str());

        out << "# vtk DataFile Version 2.0 " << endl;
        out << "LBM by Guo " << endl;
        out << "ASCII " << endl << endl;

        out << "DATASET STRUCTURED_POINTS " << endl;
        out << "DIMENSIONS  " << _Nx << " " << _Ny << " " << _Nz << endl;
        out << "ORIGIN    " << 0 << " " << 0 << " " << 0 << endl;
        out << "SPACING    " << 1.0 << " " << 1.0 << " " << 1.0 << endl << endl;

        out << "POINT_DATA    " << _sizeGM << endl << endl;

        out << "SCALARS " << nameVariable << " float" << endl;
        out << "LOOKUP_TABLE default" << endl;

        if (Cu == 1.0){
            for (jz = 0; jz < _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                out << (float)Vara[j1] << endl;
            }
        }
        else {
            for (jz = 0; jz < _Nz; jz++)
            for (jy = 0; jy < _Ny; jy++)
            for (jx = 0; jx < _Nx; jx++) {
                j1 = jz * _NxNy + jy * _Nx + jx;
                out << (float)Vara[j1] * Cu  << endl;
            }
        }
    out.close();
}

